document.addEventListener('DOMContentLoaded', async function () {
  if (!AdminLayout.ensureAdmin()) return;

  const content = document.getElementById('adminContent');
  content.innerHTML = AdminLayout.wrap('admin/users.html', `<div id="innerContent"></div>`);
  const inner = document.getElementById('innerContent');
  inner.innerHTML = '<div class="empty-state">Загрузка...</div>';

  async function load() {
    try {
      const data = await API.get('/users');
      const users = data.users;
      inner.innerHTML = `
        <h2 class="mb-16">Пользователи</h2>
        <button class="btn btn-primary mb-16" id="createAgentBtn">+ Добавить обработчика</button>
        <div class="table-wrap"><table class="table">
          <thead><tr><th>ID</th><th>ФИО</th><th>Email</th><th>Телефон</th><th>Роль</th><th>Дата регистрации</th><th></th></tr></thead>
          <tbody>
            ${users.map(u => `
              <tr>
                <td>${u.id}</td>
                <td><strong>${Auth.esc(u.full_name)}</strong></td>
                <td>${Auth.esc(u.email)}</td>
                <td>${Auth.esc(u.phone || '—')}</td>
                <td><span class="badge ${u.role === 'admin' ? 'badge-blue' : u.role === 'agent' ? 'badge-yellow' : 'badge-gray'}">${Auth.roleName(u.role)}</span></td>
                <td>${u.role === 'client' ? Auth.fmtDate(u.created_at) : '—'}</td>
                <td style="white-space:nowrap;">
                  ${u.role !== 'admin' ? `
                    <select class="form-control roleSel" data-id="${u.id}" style="width:130px;display:inline-block;margin-right:6px;">
                      <option value="client" ${u.role === 'client' ? 'selected' : ''}>Клиент</option>
                      <option value="agent" ${u.role === 'agent' ? 'selected' : ''}>Обработчик</option>
                    </select>` : ''}
                  ${u.role !== 'admin' ? `<button class="btn btn-sm btn-red delUserBtn" data-id="${u.id}">Удалить</button>` : ''}
                </td>
              </tr>`).join('')}
          </tbody>
        </table></div>`;

      inner.querySelectorAll('.delUserBtn').forEach(b => b.addEventListener('click', async () => {
        if (!confirm('Удалить пользователя?')) return;
        try {
          await API.del('/users/' + b.dataset.id);
          Common.showAlert('Пользователь удалён', 'success');
          load();
        } catch (err) { Common.showAlert(err.message, 'error'); }
      }));

      inner.querySelectorAll('.roleSel').forEach(sel => sel.addEventListener('change', async () => {
        try {
          await API.put('/users/' + sel.dataset.id, { role: sel.value });
          Common.showAlert('Права обновлены', 'success');
          load();
        } catch (err) { Common.showAlert(err.message, 'error'); load(); }
      }));

      document.getElementById('createAgentBtn').addEventListener('click', openAgentModal);
    } catch (err) {
      Common.showAlert(err.message, 'error');
    }
  }

  function openAgentModal() {
    const overlay = document.createElement('div');
    overlay.className = 'modal-backdrop show';
    overlay.innerHTML = `
      <div class="modal">
        <h3>Создание агента</h3>
        <div class="form-group"><label class="form-label form-required">ФИО</label><input type="text" class="form-control" id="aFullName" /></div>
        <div class="form-group"><label class="form-label form-required">Email</label><input type="email" class="form-control" id="aEmail" /></div>
        <div class="form-group"><label class="form-label">Телефон</label><input type="tel" class="form-control" id="aPhone" /></div>
        <div class="form-group"><label class="form-label">Рабочие часы</label><input type="text" class="form-control" id="aHours" placeholder="Пн-Пт 9:00-18:00" /></div>
        <div class="form-group"><label class="form-label form-required">Пароль</label><input type="password" class="form-control" id="aPass" minlength="6" /></div>
        <div class="modal-actions">
          <button class="btn btn-gray" id="cancelAgent">Отмена</button>
          <button class="btn btn-primary" id="saveAgent">Создать</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);

    overlay.querySelector('#cancelAgent').addEventListener('click', () => overlay.remove());
    overlay.querySelector('#saveAgent').addEventListener('click', async () => {
      const btn = document.getElementById('saveAgent');
      Common.loading(btn, 'Создание...');
      try {
        await API.post('/admin/agents', {
          full_name: document.getElementById('aFullName').value.trim(),
          email: document.getElementById('aEmail').value.trim(),
          phone: document.getElementById('aPhone').value.trim(),
          work_hours: document.getElementById('aHours').value.trim(),
          password: document.getElementById('aPass').value
        });
        Common.showAlert('Агент создан', 'success');
        overlay.remove();
        load();
      } catch (err) { Common.showAlert(err.message, 'error'); }
      finally { Common.doneLoading(btn); }
    });
  }

  await load();
});